# Dataset sintético de ecommerce (2025-01-01 a 2025-12-31)

Moneda: USD. Datos generados con `generate_ecommerce_dataset.py` (semilla 42, reproducible).
Todas las tablas salen de la misma simulación de 155.452 sesiones, así que los totales coinciden entre tablas.

## Relaciones
- `web_navigation_events.session_id` / `user_id` (= `customer_id`) / `order_id`  ->  `order_financials`
- `daily_traffic` y `daily_orders` se unen por (`date`, `channel`)
- `channel_performance` es el agregado mensual por `channel`

## daily_traffic (fila = día x canal, 2.555 filas)
date, channel, sessions, users, new_users, page_views, pages_per_session, bounce_rate, avg_session_duration_sec, mobile_share

## daily_orders (fila = día x canal, 2.555 filas)
date, channel, orders, units, new_customer_orders, returning_customer_orders, cancelled_orders, returned_orders, gross_revenue, avg_order_value, conversion_rate
(`avg_order_value` es nulo cuando no hubo órdenes ese día/canal.)

## order_financials (fila = orden, 2.908 filas)
order_id, order_date, order_timestamp, customer_id, channel, product_category, units, unit_price,
gross_revenue (units x unit_price), discount_amount, shipping_fee, tax_amount (IVA 21%),
net_revenue (gross - descuento), cogs, gross_profit (net - cogs), payment_method,
order_status (delivered / returned / cancelled / shipped / processing), refund_amount,
total_paid (net + tax + shipping)

## channel_performance (fila = mes x canal, 84 filas)
month, channel, impressions, clicks, ctr, spend, cpc, sessions, orders, conversion_rate, new_customers,
gross_revenue, net_revenue, gross_profit, profit_after_ad_spend, roas, cac
(Canales sin inversión — organic_search, direct, referral — tienen ctr/cpc/roas/cac nulos.)

## web_navigation_events (fila = evento, 480.195 filas)
event_id, session_id, user_id, event_timestamp, event_type, page_url, channel, device, country, order_id
event_type: page_view -> view_item -> add_to_cart -> begin_checkout -> purchase
(`order_id` solo viene completo en eventos `purchase`; el resto es nulo.)

## Patrones plantados para encontrar en el análisis
- Estacionalidad: Hot Sale (12-14 mayo), Black Friday (24-28 nov), Cyber Monday (1 dic), pico de Navidad, enero flojo.
- Crecimiento de tráfico a lo largo del año.
- Email y direct convierten mucho más que social_paid; social_paid tiene ROAS < 1.
- Mobile tiene más tráfico pero menor conversión que desktop.
- Fashion tiene la mayor tasa de devoluciones.
- Los descuentos suben en eventos comerciales.
- Usuarios recurrentes convierten más que nuevos.
