"""
Generador de dataset sintético de ecommerce (año 2025).

Se simulan sesiones web día por día y canal por canal. De esas sesiones salen
TODAS las tablas, por lo que los números son consistentes entre sí:

  web_navigation_events -> eventos de cada sesión (page_view ... purchase)
  daily_traffic         -> sesiones/usuarios/rebote por día y canal
  daily_orders          -> órdenes/unidades/conversión por día y canal
  order_financials      -> una fila por orden con importes y estado
  channel_performance   -> mensual por canal: inversión, clics, CAC, ROAS...
"""
import numpy as np
import pandas as pd
from pathlib import Path

SEED = 42
rng = np.random.default_rng(SEED)
OUT = Path("ecommerce_dataset")
OUT.mkdir(exist_ok=True)

START, END = "2025-01-01", "2025-12-31"
DATES = pd.date_range(START, END, freq="D")

# ------------------------------------------------------------------ canales
CHANNELS = {
    #                 share  conv   bounce  pages  aov_mult  cpc    cost_model
    "organic_search": dict(share=0.28, conv=0.026, bounce=0.42, pages=4.2, aov=1.00, cpc=0.0),
    "paid_search":    dict(share=0.20, conv=0.034, bounce=0.38, pages=4.5, aov=1.05, cpc=0.85),
    "social_paid":    dict(share=0.16, conv=0.014, bounce=0.58, pages=3.1, aov=0.85, cpc=0.55),
    "email":          dict(share=0.10, conv=0.052, bounce=0.30, pages=5.0, aov=1.15, cpc=0.12),
    "direct":         dict(share=0.14, conv=0.040, bounce=0.35, pages=4.8, aov=1.10, cpc=0.0),
    "referral":       dict(share=0.06, conv=0.022, bounce=0.46, pages=3.8, aov=0.95, cpc=0.0),
    "affiliate":      dict(share=0.06, conv=0.030, bounce=0.44, pages=3.9, aov=0.90, cpc=0.70),
}
CH_NAMES = list(CHANNELS)

CATEGORIES = {
    #                 weight  median_price  sigma  cogs_pct  avg_units
    "Electronics":    (0.20, 140, 0.70, 0.72),
    "Fashion":        (0.24, 55,  0.45, 0.45),
    "Home & Kitchen": (0.18, 60,  0.55, 0.52),
    "Beauty":         (0.14, 28,  0.40, 0.38),
    "Sports":         (0.10, 70,  0.55, 0.55),
    "Toys":           (0.08, 32,  0.45, 0.50),
    "Books":          (0.06, 18,  0.35, 0.60),
}
CAT_NAMES = list(CATEGORIES)
CAT_P = np.array([v[0] for v in CATEGORIES.values()])

PAGES = ["/home", "/category/{c}", "/search", "/deals", "/blog", "/about"]
DEVICES = ["mobile", "desktop", "tablet"]
DEVICE_P = [0.62, 0.32, 0.06]
COUNTRIES = ["AR", "MX", "CL", "CO", "UY", "ES", "US"]
COUNTRY_P = [0.38, 0.20, 0.12, 0.10, 0.05, 0.08, 0.07]
PAYMENTS = ["credit_card", "debit_card", "digital_wallet", "bank_transfer", "cash_voucher"]
PAY_P = [0.46, 0.18, 0.24, 0.08, 0.04]

# --------------------------------------------------------------- estacionalidad
def day_multiplier(d: pd.Timestamp) -> tuple[float, float, float]:
    """devuelve (tráfico, conversión, descuento_extra)"""
    t, c, disc = 1.0, 1.0, 0.0
    # crecimiento anual suave
    t *= 1 + 0.25 * (d.dayofyear / 365)
    # día de la semana (más tráfico lun-jue, menos sábado)
    t *= [1.05, 1.05, 1.03, 1.02, 0.97, 0.88, 0.95][d.dayofweek]
    # mes
    t *= {1: 0.88, 2: 0.90, 3: 0.97, 4: 0.98, 5: 1.05, 6: 1.00,
          7: 1.02, 8: 0.97, 9: 0.98, 10: 1.03, 11: 1.20, 12: 1.30}[d.month]
    # eventos comerciales
    if d.month == 5 and 12 <= d.day <= 14:      # Hot Sale
        t *= 1.55; c *= 1.25; disc = 0.15
    if d.month == 11 and 24 <= d.day <= 28:     # Black Friday week
        ramp = {24: 1.4, 25: 1.5, 26: 1.7, 27: 1.9, 28: 2.6}[d.day]
        t *= ramp; c *= 1.30; disc = 0.22
    if d.month == 12 and d.day == 1:            # Cyber Monday
        t *= 2.0; c *= 1.25; disc = 0.18
    if d.month == 12 and 15 <= d.day <= 23:     # compras de Navidad
        t *= 1.25; c *= 1.12
    if d.month == 12 and d.day in (24, 25, 31):
        t *= 0.6; c *= 0.8
    if d.month == 1 and d.day <= 6:             # Reyes / rebajas
        disc = 0.10
    return t, c, disc

BASE_SESSIONS = 360          # sesiones/día a principios de año (todos los canales)

# ---------------------------------------------------------------- simulación
sessions_rows, events_rows, orders_rows = [], [], []
session_counter, user_counter, order_counter = 0, 0, 0

for d in DATES:
    t_mult, c_mult, extra_disc = day_multiplier(d)
    for ch in CH_NAMES:
        p = CHANNELS[ch]
        n = rng.poisson(BASE_SESSIONS * p["share"] * t_mult)
        if n == 0:
            continue

        sid = np.arange(session_counter + 1, session_counter + n + 1)
        session_counter += n

        # usuarios nuevos vs recurrentes
        ret_prob = {"email": 0.75, "direct": 0.55}.get(ch, 0.28)
        is_new = rng.random(n) > ret_prob
        if user_counter == 0:
            is_new[:] = True
        uid = np.empty(n, dtype=np.int64)
        n_new = int(is_new.sum())
        uid[is_new] = np.arange(user_counter + 1, user_counter + n_new + 1)
        uid[~is_new] = rng.integers(1, user_counter + 1, size=int((~is_new).sum()))
        user_counter += n_new

        device = rng.choice(DEVICES, size=n, p=DEVICE_P)
        country = rng.choice(COUNTRIES, size=n, p=COUNTRY_P)

        # horario: pico a la noche
        hour_p = np.array([2, 1, 1, 1, 1, 2, 3, 5, 6, 6, 6, 6, 6, 6, 6, 6, 6, 7, 8, 9, 10, 10, 8, 5], float)
        hour_p /= hour_p.sum()
        hour = rng.choice(24, size=n, p=hour_p)
        start_ts = (d + pd.to_timedelta(hour, unit="h")
                    + pd.to_timedelta(rng.integers(0, 3600, size=n), unit="s"))

        # embudo (la conversión depende de canal, dispositivo, recurrencia y evento)
        dev_conv = np.where(device == "desktop", 1.25, np.where(device == "tablet", 1.0, 0.85))
        rec_conv = np.where(is_new, 0.85, 1.25)
        conv_target = p["conv"] * c_mult * dev_conv * rec_conv
        conv_target = np.clip(conv_target, 0, 0.35)

        bounced = rng.random(n) < np.clip(p["bounce"] * np.where(device == "mobile", 1.1, 0.92), 0, 0.9)
        n_pages = np.where(bounced, 1, 1 + rng.poisson(max(p["pages"] - 1.5, 0.5), size=n))

        # etapas: P(purchase) = conv_target, repartida en etapas condicionales
        # view_item 0.60 -> add_to_cart 0.28 -> begin_checkout 0.55 -> purchase 0.62
        # Para respetar conv_target se ajusta la prob. de compra final.
        p_view, p_cart, p_chk = 0.60, 0.28, 0.55
        p_buy = np.clip(conv_target / (p_view * p_cart * p_chk), 0, 0.95)
        has_view = (~bounced) & (rng.random(n) < p_view)
        has_cart = has_view & (rng.random(n) < p_cart)
        has_chk = has_cart & (rng.random(n) < p_chk)
        has_buy = has_chk & (rng.random(n) < p_buy)

        sessions_rows.append(pd.DataFrame({
            "session_id": sid, "user_id": uid, "date": d, "channel": ch,
            "device": device, "country": country, "is_new_user": is_new,
            "start_ts": start_ts, "n_pages": n_pages, "bounced": bounced,
            "has_view": has_view, "has_cart": has_cart, "has_chk": has_chk,
            "has_buy": has_buy,
        }))

        # ---------------------------------------------------------- órdenes
        buy_idx = np.where(has_buy)[0]
        m = len(buy_idx)
        if m:
            oid = np.arange(order_counter + 1, order_counter + m + 1)
            order_counter += m
            cat = rng.choice(CAT_NAMES, size=m, p=CAT_P)
            units = 1 + rng.poisson(0.55, size=m)
            median = np.array([CATEGORIES[c][1] for c in cat])
            sigma = np.array([CATEGORIES[c][2] for c in cat])
            cogs_pct = np.array([CATEGORIES[c][3] for c in cat])
            unit_price = rng.lognormal(np.log(median), sigma) * p["aov"]
            unit_price = np.round(np.clip(unit_price, 4, 1500), 2)
            gross = np.round(unit_price * units, 2)

            disc_rate = np.where(rng.random(m) < 0.35 + extra_disc * 1.5,
                                 np.clip(rng.normal(0.12 + extra_disc, 0.05), 0.02, 0.5), 0.0)
            discount = np.round(gross * disc_rate, 2)
            shipping = np.where((gross - discount) >= 80, 0.0,
                                np.round(rng.choice([4.5, 6.9, 8.5], size=m), 2))
            tax = np.round((gross - discount) * 0.21, 2)       # IVA 21%
            net = np.round(gross - discount, 2)                # ingreso neto (sin IVA ni envío)
            cogs = np.round(gross * cogs_pct * rng.uniform(0.93, 1.07, size=m), 2)
            gross_profit = np.round(net - cogs, 2)

            # estado: cancelada / devuelta / entregada
            r = rng.random(m)
            ret_p = np.where(cat == "Fashion", 0.16, np.where(cat == "Electronics", 0.07, 0.04))
            status = np.where(r < 0.035, "cancelled",
                      np.where(r < 0.035 + ret_p, "returned", "delivered"))
            refund = np.where(status == "cancelled", net,
                      np.where(status == "returned",
                               np.round(net * rng.choice([1.0, 0.5], size=m, p=[0.8, 0.2]), 2), 0.0))
            # ultimas ordenes (<10 días antes del cierre) aún en tránsito
            if (DATES[-1] - d).days < 6:
                status = np.where(status == "delivered",
                                  rng.choice(["delivered", "shipped", "processing"], size=m, p=[0.3, 0.45, 0.25]),
                                  status)

            pay = rng.choice(PAYMENTS, size=m, p=PAY_P)
            orders_rows.append(pd.DataFrame({
                "order_id": [f"ORD-{x:07d}" for x in oid],
                "order_date": d, "order_ts": start_ts[buy_idx] + pd.to_timedelta(rng.integers(120, 1500, size=m), unit="s"),
                "session_id": sid[buy_idx], "customer_id": [f"CUST-{x:06d}" for x in uid[buy_idx]],
                "channel": ch, "device": device[buy_idx], "country": country[buy_idx],
                "product_category": cat, "units": units, "unit_price": unit_price,
                "gross_revenue": gross, "discount_amount": discount, "shipping_fee": shipping,
                "tax_amount": tax, "net_revenue": net, "cogs": cogs, "gross_profit": gross_profit,
                "payment_method": pay, "order_status": status, "refund_amount": refund,
                "is_first_order": is_new[buy_idx],
            }))

# ------------------------------------------------------------------ ensamblado
sessions = pd.concat(sessions_rows, ignore_index=True)
orders = pd.concat(orders_rows, ignore_index=True)
order_by_session = orders.set_index("session_id")["order_id"]

# ---- eventos ---------------------------------------------------------------
ev_parts = []
s = sessions

# page_views (el primero es la landing)
reps = s["n_pages"].to_numpy()
idx = np.repeat(np.arange(len(s)), reps)
seq = np.concatenate([np.arange(k) for k in reps])
pv = pd.DataFrame({"session_id": s["session_id"].to_numpy()[idx], "seq": seq})
pv["event_type"] = "page_view"
pv["seq"] = pv["seq"] * 10  # deja espacio para eventos de embudo
ev_parts.append(pv)

for flag, name, base in [("has_view", "view_item", 5), ("has_cart", "add_to_cart", 100),
                         ("has_chk", "begin_checkout", 200), ("has_buy", "purchase", 300)]:
    sub = s.loc[s[flag], ["session_id"]].copy()
    sub["seq"] = base
    sub["event_type"] = name
    ev_parts.append(sub)

ev = pd.concat(ev_parts, ignore_index=True).sort_values(["session_id", "seq"], kind="stable")
ev = ev.merge(s[["session_id", "user_id", "channel", "device", "country", "start_ts", "n_pages", "bounced"]],
              on="session_id", how="left")

# timestamps: acumulado de pausas aleatorias dentro de cada sesión
gaps = rng.gamma(2.0, 22.0, size=len(ev)).round().astype(int) + 3
ev["gap"] = gaps
first = ev.groupby("session_id").cumcount() == 0
ev.loc[first, "gap"] = 0
ev["offset"] = ev.groupby("session_id")["gap"].cumsum()
ev["event_ts"] = ev["start_ts"] + pd.to_timedelta(ev["offset"], unit="s")

# URLs / productos
cats_for_url = rng.choice(CAT_NAMES, size=len(ev), p=CAT_P)
page_choice = rng.choice(len(PAGES), size=len(ev), p=[0.30, 0.34, 0.14, 0.12, 0.06, 0.04])
page_url = np.array([PAGES[i].format(c=c.lower().replace(" & ", "-").replace(" ", "-"))
                     for i, c in zip(page_choice, cats_for_url)], dtype=object)
is_first_pv = (ev["event_type"] == "page_view") & (ev["seq"] == 0)
landing = {"organic_search": "/category/{c}", "paid_search": "/category/{c}", "social_paid": "/deals",
           "email": "/deals", "direct": "/home", "referral": "/blog", "affiliate": "/category/{c}"}
page_url[is_first_pv.to_numpy()] = [
    landing[ch].format(c=c.lower().replace(" & ", "-").replace(" ", "-"))
    for ch, c in zip(ev.loc[is_first_pv, "channel"], cats_for_url[is_first_pv.to_numpy()])]
prod = rng.integers(1000, 1600, size=len(ev))
fun = ev["event_type"].isin(["view_item", "add_to_cart", "begin_checkout", "purchase"]).to_numpy()
page_url[fun & (ev["event_type"] == "view_item").to_numpy()] = [f"/product/{p}" for p in prod[fun & (ev["event_type"] == "view_item").to_numpy()]]
page_url[(ev["event_type"] == "add_to_cart").to_numpy()] = "/cart"
page_url[(ev["event_type"] == "begin_checkout").to_numpy()] = "/checkout"
page_url[(ev["event_type"] == "purchase").to_numpy()] = "/checkout/confirmation"
ev["page_url"] = page_url
ev["order_id"] = np.where(ev["event_type"] == "purchase", ev["session_id"].map(order_by_session), None)

ev = ev.sort_values(["event_ts", "session_id", "seq"]).reset_index(drop=True)
ev["event_id"] = [f"EVT-{i:08d}" for i in range(1, len(ev) + 1)]
ev["session_id_str"] = ev["session_id"].map(lambda x: f"SES-{x:07d}")
ev["user_id_str"] = ev["user_id"].map(lambda x: f"CUST-{x:06d}")

web_events = ev[["event_id", "session_id_str", "user_id_str", "event_ts", "event_type", "page_url",
                 "channel", "device", "country", "order_id"]].rename(
    columns={"session_id_str": "session_id", "user_id_str": "user_id", "event_ts": "event_timestamp"})

# duración de sesión a partir de eventos
dur = ev.groupby("session_id")["offset"].max()
s = s.assign(duration_sec=s["session_id"].map(dur).fillna(0).astype(int))

# ---- daily_traffic ---------------------------------------------------------
traffic = (s.groupby(["date", "channel"])
    .agg(sessions=("session_id", "count"),
         users=("user_id", "nunique"),
         new_users=("is_new_user", "sum"),
         page_views=("n_pages", "sum"),
         bounced=("bounced", "sum"),
         total_duration=("duration_sec", "sum"),
         mobile_sessions=("device", lambda x: (x == "mobile").sum()))
    .reset_index())
traffic["bounce_rate"] = (traffic["bounced"] / traffic["sessions"]).round(4)
traffic["avg_session_duration_sec"] = (traffic["total_duration"] / traffic["sessions"]).round(1)
traffic["pages_per_session"] = (traffic["page_views"] / traffic["sessions"]).round(2)
traffic["mobile_share"] = (traffic["mobile_sessions"] / traffic["sessions"]).round(4)
daily_traffic = traffic[["date", "channel", "sessions", "users", "new_users", "page_views",
                         "pages_per_session", "bounce_rate", "avg_session_duration_sec", "mobile_share"]]

# ---- daily_orders ----------------------------------------------------------
oo = orders.copy()
g = oo.groupby(["order_date", "channel"])
daily_orders = g.agg(
    orders=("order_id", "count"),
    units=("units", "sum"),
    new_customer_orders=("is_first_order", "sum"),
    cancelled_orders=("order_status", lambda x: (x == "cancelled").sum()),
    returned_orders=("order_status", lambda x: (x == "returned").sum()),
    gross_revenue=("gross_revenue", "sum"),
).reset_index().rename(columns={"order_date": "date"})
daily_orders = traffic[["date", "channel", "sessions"]].merge(daily_orders, on=["date", "channel"], how="left")
for col in ["orders", "units", "new_customer_orders", "cancelled_orders", "returned_orders", "gross_revenue"]:
    daily_orders[col] = daily_orders[col].fillna(0)
daily_orders["conversion_rate"] = (daily_orders["orders"] / daily_orders["sessions"]).round(4)
daily_orders["avg_order_value"] = (daily_orders["gross_revenue"] / daily_orders["orders"].replace(0, np.nan)).round(2)
daily_orders["returning_customer_orders"] = daily_orders["orders"] - daily_orders["new_customer_orders"]
daily_orders = daily_orders[["date", "channel", "orders", "units", "new_customer_orders",
                             "returning_customer_orders", "cancelled_orders", "returned_orders",
                             "gross_revenue", "avg_order_value", "conversion_rate"]]
for col in ["orders", "units", "new_customer_orders", "returning_customer_orders",
            "cancelled_orders", "returned_orders"]:
    daily_orders[col] = daily_orders[col].astype(int)
daily_orders["gross_revenue"] = daily_orders["gross_revenue"].round(2)

# ---- order_financials ------------------------------------------------------
order_financials = orders[["order_id", "order_date", "order_ts", "customer_id", "channel",
                           "product_category", "units", "unit_price", "gross_revenue",
                           "discount_amount", "shipping_fee", "tax_amount", "net_revenue",
                           "cogs", "gross_profit", "payment_method", "order_status",
                           "refund_amount"]].copy()
order_financials["total_paid"] = (order_financials["net_revenue"] + order_financials["tax_amount"]
                                  + order_financials["shipping_fee"]).round(2)
order_financials = order_financials.rename(columns={"order_ts": "order_timestamp"})

# ---- channel_performance (mensual) ----------------------------------------
s["month"] = s["date"].dt.to_period("M").dt.to_timestamp()
orders["month"] = orders["order_date"].dt.to_period("M").dt.to_timestamp()
sess_m = s.groupby(["month", "channel"]).agg(sessions=("session_id", "count"),
                                             new_users=("is_new_user", "sum")).reset_index()
ord_m = orders.groupby(["month", "channel"]).agg(
    orders=("order_id", "count"), gross_revenue=("gross_revenue", "sum"),
    net_revenue=("net_revenue", "sum"), gross_profit=("gross_profit", "sum"),
    new_customers=("is_first_order", "sum")).reset_index()
cp = sess_m.merge(ord_m, on=["month", "channel"], how="left").fillna(0)

# inversión: sesiones pagas * CPC (con ruido y mayor costo en eventos de fin de año)
cpc = cp["channel"].map(lambda c: CHANNELS[c]["cpc"])
season_cost = cp["month"].dt.month.map({11: 1.35, 12: 1.30, 5: 1.12}).fillna(1.0)
noise = rng.normal(1.0, 0.04, size=len(cp))
cp["clicks"] = (cp["sessions"] * np.where(cpc > 0, rng.uniform(1.02, 1.08, len(cp)), 0)).round().astype(int)
cp["spend"] = (cp["clicks"] * cpc * season_cost * noise).round(2)
ctr = cp["channel"].map({"paid_search": 0.045, "social_paid": 0.012, "affiliate": 0.020, "email": 0.028}).fillna(0)
cp["impressions"] = np.where(ctr > 0, (cp["clicks"] / ctr).round(), 0).astype(int)
cp["ctr"] = np.where(cp["impressions"] > 0, (cp["clicks"] / cp["impressions"].replace(0, np.nan)), np.nan).round(4)
cp["cpc"] = np.where(cp["clicks"] > 0, cp["spend"] / cp["clicks"].replace(0, np.nan), np.nan).round(3)
cp["conversion_rate"] = (cp["orders"] / cp["sessions"]).round(4)
cp["roas"] = np.where(cp["spend"] > 0, cp["gross_revenue"] / cp["spend"].replace(0, np.nan), np.nan).round(2)
cp["cac"] = np.where((cp["spend"] > 0) & (cp["new_customers"] > 0),
                     cp["spend"] / cp["new_customers"].replace(0, np.nan), np.nan).round(2)
cp["gross_revenue"] = cp["gross_revenue"].round(2)
cp["net_revenue"] = cp["net_revenue"].round(2)
cp["gross_profit"] = cp["gross_profit"].round(2)
cp["profit_after_ad_spend"] = (cp["gross_profit"] - cp["spend"]).round(2)
for col in ["orders", "new_customers"]:
    cp[col] = cp[col].astype(int)
channel_performance = cp[["month", "channel", "impressions", "clicks", "ctr", "spend", "cpc",
                          "sessions", "orders", "conversion_rate", "new_customers",
                          "gross_revenue", "net_revenue", "gross_profit",
                          "profit_after_ad_spend", "roas", "cac"]]

# ------------------------------------------------------------------- guardado
daily_traffic.to_csv(OUT / "daily_traffic.csv", index=False)
daily_orders.to_csv(OUT / "daily_orders.csv", index=False)
order_financials.to_csv(OUT / "order_financials.csv", index=False)
channel_performance.to_csv(OUT / "channel_performance.csv", index=False)
web_events.to_csv(OUT / "web_navigation_events.csv", index=False)

for name, df in [("channel_performance", channel_performance), ("daily_orders", daily_orders),
                 ("daily_traffic", daily_traffic), ("order_financials", order_financials),
                 ("web_navigation_events", web_events)]:
    print(f"{name:24s} {len(df):>9,d} filas  {df.shape[1]:>2d} columnas")
